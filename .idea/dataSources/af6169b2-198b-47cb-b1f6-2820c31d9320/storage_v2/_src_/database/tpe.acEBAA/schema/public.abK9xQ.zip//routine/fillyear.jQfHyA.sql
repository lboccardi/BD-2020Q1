create function fillyear(date date) returns void
    language plpgsql
as
$$
declare
     year int := 0;
     is_leap bool := 0;
 begin
     year := extract (year from date);
     is_leap := checkLeapYear(year);
     insert into year values (year, is_leap);
 end;
$$;

alter function fillyear(date) owner to postgres;

