create function checkleapyear(year integer) returns boolean
    language plpgsql
as
$$
begin
    	return (year % 4 = 0) AND ((year % 100 <> 0) or (year % 400 = 0));
    end;
$$;

alter function checkleapyear(integer) owner to postgres;

