create function get_weekday(weekday integer) returns character varying
    language plpgsql
as
$$
begin
        case weekday
        when 0 then return 'domingo';
        when 1 then return 'lunes';
        when 2 then return 'martes';
        when 3 then return 'miercoles';
        when 4 then return 'jueves';
        when 5 then return 'viernes';
        when 6 then return 'sabado';
        else raise exception 'error number';
        end case;
end;
$$;

alter function get_weekday(integer) owner to postgres;

