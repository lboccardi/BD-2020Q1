create function filldatedetails(date date, monthid integer) returns integer
    language plpgsql
as
$$
declare
 	dayNum integer;
	dow varchar(20);
	isWeekend boolean:= false;
	dateId integer;
 begin
	 dayNum := extract (day from date);
	 dow := extract(dow from date);
	 if dow = 0 or dow = 6 then
	 	isWeekend:= true;
	end if;
	
	insert into datedetail(day,dayofweek,weekend,monthfk) values (dayNum, dow,isWeekend, monthId);
	 
	select id into dateId from datedetail where dayNum = datedetail.day and monthId = datedetail.monthfk;
	
	return dateId;
 end;
$$;

alter function filldatedetails(date, integer) owner to postgres;

