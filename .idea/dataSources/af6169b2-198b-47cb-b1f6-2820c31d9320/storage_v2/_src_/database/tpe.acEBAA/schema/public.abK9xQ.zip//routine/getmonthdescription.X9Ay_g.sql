create function getmonthdescription(month integer) returns character varying
    language plpgsql
as
$$
BEGIN
		case month
			when 1 then return'Enero';
			when 2 then return'Febrero';
			when 3 then return'Marzo';
			when 4 then return'Abril';
			when 5 then return'Mayo';
			when 6 then return'Junio';
			when 7 then return'Julio';
			when 8 then return'Agosto';
			when 9 then return'Septiembre';
			when 10 then return'Octubre';
			when 11 then return'Noviembre';
			when 12 then return'Diciembre';
			else raise exception 'Invalid Month';
			end case;
	END;
$$;

alter function getmonthdescription(integer) owner to postgres;

