create function getmonthdescription(month integer) returns character varying
    language plpgsql
as
$$
DECLARE 
  	monthDescription varchar(200):='basura';
	
  BEGIN
	if month = 1 then 
		monthDescription := 'Enero';
	elseif month = 2 then  
		monthDescription := 'Febrero';
 	elseif month = 3 then  
		monthDescription := 'Marzo';
 	elseif month = 4 then  
		monthDescription := 'Abril';
 	elseif month = 5 then  
		monthDescription := 'Mayo';
 	elseif month = 6 then  
		monthDescription := 'Junio';
 	elseif month = 7 then  
		monthDescription := 'Julio';
 	elseif month = 8 then  
		monthDescription := 'Agosto';
 	elseif month = 9 then  
		monthDescription := 'Septiembre';
 	elseif month = 10 then  
		monthDescription := 'Octubre';
 	elseif month = 11 then  
		monthDescription := 'Noviembre';
    elseif month = 12 then  
		monthDescription := 'Diciembre';
  	else 
		raise exception 'Invalid Month';
	end if;
	
    RETURN monthDescription;
  END;
$$;

alter function getmonthdescription(integer) owner to postgres;

