create function fillmonth(monthnum integer, quarterid integer) returns integer
    language plpgsql
as
$$
declare
	 monthDesc varchar(20);
     monthID integer;
 begin
	 monthDesc := GetMonthDescription(monthNum);
     insert into month(monthid,monthdesc,quarterfk) values (monthNum, monthDesc, quarterId);
	 
	 select id into monthID from month where month.monthid = monthNum and month.quarterfk = quarterId;
	 
	 if monthID is null then
	 	raise exception 'Month wasnt inserted';
	 end if;
	 
	 return monthID;
	 
 end;
$$;

alter function fillmonth(integer, integer) owner to postgres;

