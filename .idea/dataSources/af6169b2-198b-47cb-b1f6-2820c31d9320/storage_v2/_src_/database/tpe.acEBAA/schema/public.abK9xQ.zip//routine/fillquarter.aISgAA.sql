create function fillquarter(quarter_num integer, year integer) returns integer
    language plpgsql
as
$$
declare
		ret integer;
	begin
		insert into quarter(quarternumber,yearfk) values (quarter_num, year);
		select id into ret from quarter where quarternumber = quarter_num and yearfk = year;
		return ret;
	end;
$$;

alter function fillquarter(integer, integer) owner to postgres;

