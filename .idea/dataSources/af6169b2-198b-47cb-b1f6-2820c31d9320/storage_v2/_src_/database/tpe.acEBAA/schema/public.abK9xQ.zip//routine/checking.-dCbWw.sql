create function checking() returns trigger
    language plpgsql
as
$$
DECLARE
		date date = new.Declaration_Date;
	    month integer = extract(month from date);
		vyear integer = extract(year from date);
		vday integer = extract(day from date);
		quarter integer = (month/4) + 1;
		quarterId integer = -1;
		monthId integer = -1;
		dateDetail integer = -1;
	BEGIN
		if not exists (select t1.year from YEAR as t1 where t1.year = vyear) then
			execute fillYear(date);
		end if;
		select t1.id into quarterId from QUARTER as t1 where t1.quarternumber=quarter;
		if  quarterId is null then
			quarterId := fillQuarter(quarter,vyear);
		end if;
		select t1.id into monthId from MONTH as t1 where t1.monthid=month;
		if  monthId is null then
			monthid := fillMonth(month,quarterId);
		end if;
		select t1.id into dateDetail from DATEDETAIL as t1 where t1.day=vday and t1.monthfk=monthId;
		if  dateDetail is null then
			dateDetail := FillDateDetails(date,monthId);
		end if;
		raise notice 'hola';
		new.Declaration_Date := dateDetail;
        raise notice '%',new.Declaration_Date;
		insert into EVENT values (new.Declaration_Number,new.Declaration_Type,new.Declaration_Date,new.State,new.Disaster_Type);
        return new;
	END;
$$;

alter function checking() owner to postgres;

