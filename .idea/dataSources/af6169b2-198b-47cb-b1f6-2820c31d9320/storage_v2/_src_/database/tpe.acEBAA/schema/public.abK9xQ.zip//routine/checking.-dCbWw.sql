create function checking() returns trigger
    language plpgsql
as
$$
DECLARE
date date = new.Declaration_Date;
month integer = extract(month from date);
year integer = extract(year from date);
day integer = extract(day from date);
quarter integer = (month/4) + 1;
quarterId integer = -1;
monthId integer = -1;
dateDetail integer = -1;
BEGIN
    if not exists (select from YEAR as t1 where t1.year == year) then
        execute fillYear(year);
    end if;
    select t1.id into quarterId from QUARTER as t1 where t1.quarternumber==quarter;
    if  quarterId is null then
        quarterId := fillQuarter(quarter,year);
    end if;
    select t1.id into monthId from MONTH as t1 where t1.monthid==month;
    if  monthId is null then
        monthid := fillMonth(month,quarterId);
    end if;
    select t1.id into dateDetail from DATEDETAIL as t1 where t1.day==day && t1.monthfk=monthId;
    if  dateDetail is null then
        dateDetail := FillDateDetails(date,monthId);
    end if;
    new.Declaration_Date := dateDetail;

END;
$$;

alter function checking() owner to postgres;

